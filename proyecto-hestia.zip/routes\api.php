<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\GoogleAuthController;
use App\Http\Controllers\Api\PasswordResetController;
use App\Http\Controllers\Api\LessonController;
use App\Http\Controllers\Api\EvaluationController;
use App\Http\Controllers\Api\ProgressController;
use App\Http\Controllers\Api\ReportController;
use App\Http\Controllers\Api\AdminController;
use App\Http\Controllers\Api\NotificationController;
use App\Http\Controllers\Api\DeviceController;
use App\Http\Controllers\Api\AiController;
use App\Http\Controllers\Api\ParentController;
use App\Http\Controllers\Api\GuestStudentController;
use App\Http\Controllers\Api\ExamController;
use App\Http\Controllers\Api\SubmittedWorkController;
use App\Http\Controllers\Api\RankingController;
use App\Http\Controllers\Api\GamificationController;
use App\Http\Controllers\Api\AcademicEventController;
use App\Http\Controllers\Api\SystemTranslationController;
use App\Http\Controllers\Api\PushSubscriptionController;
use App\Http\Controllers\Api\MessageController;
use App\Http\Controllers\Api\ForumController;
use App\Http\Controllers\Api\SalonController;
use App\Http\Controllers\Api\GameController;

/*
|--------------------------------------------------------------------------
| API Routes — v1
|--------------------------------------------------------------------------
*/

Route::prefix('v1')->group(function () {

    // ============================================================
    // RUTAS PÚBLICAS (No requieren autenticación)
    // ============================================================

    Route::prefix('auth')->group(function () {
        
        // Autenticación tradicional (email + password)
        Route::post('/register', [AuthController::class, 'register'])
            ->middleware('throttle:5,1');
        Route::post('/login', [AuthController::class, 'login'])
            ->middleware('throttle:10,1');
        
        // Google OAuth
        Route::get('/google/redirect', [GoogleAuthController::class, 'redirectToGoogle'])
            ->middleware('throttle:30,1');
        Route::get('/google/callback', [GoogleAuthController::class, 'handleGoogleCallback'])
            ->middleware('throttle:30,1');
        Route::post('/google/exchange-code', [GoogleAuthController::class, 'exchangeCode'])
            ->middleware('throttle:10,1');
        Route::post('/google/login', [GoogleAuthController::class, 'loginWithGoogleToken'])
            ->middleware('throttle:10,1');
        
        // Recuperación de contraseña
        Route::post('/forgot-password', [PasswordResetController::class, 'sendResetLink'])
            ->middleware('throttle:5,1');
        Route::post('/reset-password', [PasswordResetController::class, 'resetPassword'])
            ->middleware('throttle:5,1');
    });

    // ============================================================
    // RUTAS PROTEGIDAS (Requieren autenticación con Sanctum)
    // ============================================================

    Route::middleware(['auth:sanctum', 'auth.active', 'rate.limit'])->group(function () {

        // ============================================================
        // AI CHAT (Proxy seguro - protege la API key de Groq)
        // ============================================================
        Route::post('/ai/chat', [AiController::class, 'chat'])
            ->middleware('throttle:20,1');
        Route::post('/ai/generate-lesson', [AiController::class, 'generateLesson'])
            ->middleware(['role:teacher,admin', 'throttle:10,1']);

        // ============================================================
        // PERFIL DE USUARIO (Todos los roles)
        // ============================================================
        
        Route::prefix('user')->group(function () {
            Route::get('/profile', [AuthController::class, 'profile'])
                ->middleware('cache.api');
            Route::put('/profile', [AuthController::class, 'updateProfile']);
            Route::put('/change-password', [AuthController::class, 'changePassword']);
            Route::post('/send-verification-email', [AuthController::class, 'sendVerificationEmail'])
                ->middleware('throttle:3,1');
            Route::post('/verify-email', [AuthController::class, 'verifyEmail'])
                ->middleware('throttle:5,1');
            Route::post('/connect-google', [AuthController::class, 'connectGoogle']);
            Route::post('/disconnect-google', [AuthController::class, 'disconnectGoogle']);
            Route::post('/logout', [AuthController::class, 'logout']);
            Route::post('/logout-platform', [AuthController::class, 'logoutPlatform']);
            Route::post('/logout-all', [AuthController::class, 'logoutAll']);
            Route::get('/devices', [AuthController::class, 'devices'])
                ->middleware('cache.api');
            Route::post('/refresh-token', [AuthController::class, 'refreshToken']);
        });
        
        // ============================================================
        // DISPOSITIVOS / PUSH NOTIFICATIONS
        // ============================================================
        
        Route::prefix('devices')->group(function () {
            Route::post('/register', [DeviceController::class, 'register']);
            Route::post('/unregister', [DeviceController::class, 'unregister']);
            Route::get('/', [DeviceController::class, 'list'])
                ->middleware('cache.api');
        });
        
        // ============================================================
        // NOTIFICACIONES (Todos los roles)
        // ============================================================
        
        Route::prefix('notifications')->group(function () {
            Route::get('/', [NotificationController::class, 'index'])
                ->middleware('cache.api');
            Route::get('/unread-count', [NotificationController::class, 'unreadCount'])
                ->middleware('cache.api');
            Route::put('/read-all', [NotificationController::class, 'markAllAsRead']);
            Route::delete('/read/delete', [NotificationController::class, 'deleteRead']);
            Route::put('/{id}/read', [NotificationController::class, 'markAsRead']);
            Route::delete('/{id}', [NotificationController::class, 'destroy']);
        });
        
        // ============================================================
        // DASHBOARDS (Según rol) — con soporte para mobile
        // ============================================================
        
        Route::prefix('dashboard')->group(function () {
            // Dashboard completo (web)
            Route::get('/student', [ProgressController::class, 'studentDashboard'])
                ->middleware(['role:student', 'cache.api']);
            // Dashboard ligero (mobile) — solo stats
            Route::get('/student/stats', [ProgressController::class, 'studentStats'])
                ->middleware(['role:student', 'cache.api']);
            Route::get('/teacher', [ProgressController::class, 'teacherDashboard'])
                ->middleware(['role:teacher', 'cache.api']);
            Route::get('/admin', [AdminController::class, 'dashboard'])
                ->middleware(['role:admin', 'cache.api']);
        });
        
        // ============================================================
        // PROGRESO Y ESTADÍSTICAS (Todos los roles)
        // ============================================================
        
        Route::prefix('progress')->group(function () {
            Route::get('/my-stats', [ProgressController::class, 'getMyStats'])
                ->middleware('cache.api');
            Route::get('/badges', [ProgressController::class, 'getBadges'])
                ->middleware('cache.api');
            Route::get('/level', [ProgressController::class, 'studentLevel'])
                ->middleware('cache.api');
        });
        
        // ============================================================
        // LECCIONES (Todos los roles)
        // ============================================================
        
        Route::prefix('lessons')->group(function () {
            Route::get('/', [LessonController::class, 'index'])
                ->middleware(['cache.api', 'throttle:30,1']);
            Route::get('/recommended', [LessonController::class, 'recommended'])
                ->middleware('cache.api');
            // /unit/{unit} BEFORE /{id} to avoid route collision
            Route::get('/unit/{unit}', [LessonController::class, 'getByUnit'])
                ->middleware('cache.api');
            Route::get('/{id}', [LessonController::class, 'show'])
                ->middleware('cache.api');
            // Contenido completo de lección (separado para mobile)
            Route::get('/{id}/content', [LessonController::class, 'content'])
                ->middleware('cache.api');
            Route::get('/{id}/resources', [LessonController::class, 'getResources'])
                ->middleware('cache.api');
            Route::get('/{id}/progress', [ProgressController::class, 'getLessonProgress'])
                ->middleware('cache.api');
            Route::post('/{id}/progress', [ProgressController::class, 'updateLessonProgress'])
                ->middleware(['role:student']);
            
            Route::middleware(['role:teacher'])->group(function () {
                Route::post('/', [LessonController::class, 'store']);
                Route::post('/resources/upload', [LessonController::class, 'uploadResource'])
                    ->middleware(['throttle:30,1']);
                Route::put('/{id}', [LessonController::class, 'update']);
                Route::delete('/{id}', [LessonController::class, 'destroy']);
                Route::post('/{id}/publish', [LessonController::class, 'publish']);
                Route::post('/{id}/unpublish', [LessonController::class, 'unpublish']);
                Route::post('/{id}/duplicate', [LessonController::class, 'duplicate']);
                Route::post('/{id}/resources', [LessonController::class, 'addResource']);
                Route::delete('/{id}/resources/{resourceId}', [LessonController::class, 'removeResource']);
                Route::get('/{id}/stats', [LessonController::class, 'getStats'])
                    ->middleware('cache.api');
            });
        });
        
        // ============================================================
        // EVALUACIONES (Todos los roles)
        // ============================================================
        
        Route::prefix('evaluations')->group(function () {
            Route::get('/', [EvaluationController::class, 'index'])
                ->middleware(['cache.api', 'throttle:30,1']);
            Route::get('/adaptive', [EvaluationController::class, 'adaptive'])
                ->middleware('cache.api');
            Route::get('/{id}', [EvaluationController::class, 'show'])
                ->middleware('cache.api');
            Route::get('/{evaluationId}/questions', [EvaluationController::class, 'getQuestions'])
                ->middleware('cache.api');
            Route::post('/{evaluationId}/submit', [EvaluationController::class, 'submit'])
                ->middleware(['role:student']);
            Route::get('/{evaluationId}/results', [EvaluationController::class, 'getResults'])
                ->middleware('cache.api');
            
            Route::middleware(['role:teacher,admin'])->group(function () {
                Route::get('/{evaluationId}/result/{userId}', [EvaluationController::class, 'getStudentResult'])
                    ->middleware('cache.api');
                Route::get('/{id}/stats', [EvaluationController::class, 'getStats'])
                    ->middleware('cache.api');
            });
            
            Route::middleware(['role:teacher'])->group(function () {
                Route::post('/', [EvaluationController::class, 'store']);
                Route::put('/{id}', [EvaluationController::class, 'update']);
                Route::delete('/{id}', [EvaluationController::class, 'destroy']);
                Route::post('/{id}/publish', [EvaluationController::class, 'publish']);
                Route::post('/{id}/unpublish', [EvaluationController::class, 'unpublish']);
                Route::post('/{id}/duplicate', [EvaluationController::class, 'duplicate']);
                
                Route::post('/{evaluationId}/questions', [EvaluationController::class, 'addQuestion']);
                Route::put('/questions/{questionId}', [EvaluationController::class, 'updateQuestion']);
                Route::delete('/questions/{questionId}', [EvaluationController::class, 'deleteQuestion']);
            });
        });
        
        // ============================================================
        // EXÁMENES (Teacher-created tests, separate from evaluations)
        // ============================================================

        Route::prefix('exams')->group(function () {
            Route::get('/', [ExamController::class, 'index'])
                ->middleware(['cache.api', 'throttle:30,1']);
            Route::post('/', [ExamController::class, 'store'])
                ->middleware(['role:teacher,admin']);
            Route::get('/{id}', [ExamController::class, 'show'])
                ->middleware('cache.api');
            Route::put('/{id}', [ExamController::class, 'update'])
                ->middleware(['role:teacher,admin']);
            Route::delete('/{id}', [ExamController::class, 'destroy'])
                ->middleware(['role:teacher,admin']);
            Route::post('/{id}/activate', [ExamController::class, 'activate'])
                ->middleware(['role:teacher,admin']);
            Route::post('/{id}/deactivate', [ExamController::class, 'deactivate'])
                ->middleware(['role:teacher,admin']);
            Route::post('/{id}/start', [ExamController::class, 'startAttempt'])
                ->middleware(['role:student']);
            Route::post('/attempts/{attemptId}/submit', [ExamController::class, 'submitAttempt'])
                ->middleware(['role:student']);
            Route::post('/attempts/{attemptId}/cheat', [ExamController::class, 'reportCheating'])
                ->middleware(['role:student']);
            Route::get('/{id}/stats', [ExamController::class, 'getExamStats'])
                ->middleware(['role:teacher,admin', 'cache.api']);
        });

        // ============================================================
        // SUBMITTED WORKS (Student work submissions)
        // ============================================================

        Route::get('/submitted-works', [SubmittedWorkController::class, 'index']);
        Route::post('/submitted-works', [SubmittedWorkController::class, 'store'])
            ->middleware(['role:student', 'throttle:20,1']);
        Route::get('/submitted-works/student/summary', [SubmittedWorkController::class, 'studentSummary']);
        Route::get('/submitted-works/{id}', [SubmittedWorkController::class, 'show']);
        Route::post('/submitted-works/{id}/grade', [SubmittedWorkController::class, 'grade'])
            ->middleware('role:teacher,admin');
        Route::post('/submitted-works/{id}/return', [SubmittedWorkController::class, 'returnWork'])
            ->middleware('role:teacher,admin');
        Route::post('/submitted-works/auto-generate', [SubmittedWorkController::class, 'autoGenerateFromCompleted'])
            ->middleware(['role:teacher,admin', 'throttle:10,1']);

        // ============================================================
        // RANKINGS
        // ============================================================

        Route::get('/rankings/course', [RankingController::class, 'courseRanking']);
        Route::get('/rankings/overall', [RankingController::class, 'overallRanking']);
        Route::get('/rankings/my-position', [RankingController::class, 'myPosition']);

        // ============================================================
        // REPORTES (Docentes y Admin)
        // ============================================================
        
        Route::prefix('reports')->middleware(['role:teacher,admin'])->group(function () {
            Route::get('/performance', [ReportController::class, 'performanceReport'])
                ->middleware('cache.api');
            Route::get('/filtered-performance', [ReportController::class, 'filteredPerformanceReport'])
                ->middleware('cache.api');
            Route::get('/student-detail/{studentId}', [ReportController::class, 'studentDetailReport'])
                ->middleware('cache.api');
            Route::get('/course-detail/{unit}', [ReportController::class, 'courseDetailReport'])
                ->middleware('cache.api');
            Route::get('/grades', [ReportController::class, 'gradesReport'])
                ->middleware('cache.api');
            Route::get('/student/{userId}', [ReportController::class, 'studentReport'])
                ->middleware('cache.api');
            Route::get('/participation', [ReportController::class, 'participationReport'])
                ->middleware('cache.api');
            Route::get('/export/pdf', [ReportController::class, 'exportPDF'])
                ->middleware('throttle:5,1');
            Route::get('/export/excel', [ReportController::class, 'exportExcel'])
                ->middleware('throttle:5,1');
            Route::get('/export/performance/pdf', [ReportController::class, 'exportPerformancePDF'])
                ->middleware('throttle:5,1');
            Route::get('/export/performance/excel', [ReportController::class, 'exportPerformanceExcel'])
                ->middleware('throttle:5,1');
            Route::get('/export/student/{studentId}/pdf', [ReportController::class, 'exportStudentReportPDF'])
                ->middleware('throttle:5,1');
            Route::get('/export/student/{studentId}/excel', [ReportController::class, 'exportStudentReportExcel'])
                ->middleware('throttle:5,1');
            Route::get('/export/grades/pdf', [ReportController::class, 'exportGradesPDF'])
                ->middleware('throttle:5,1');
            Route::get('/export/grades/excel', [ReportController::class, 'exportGradesExcel'])
                ->middleware('throttle:5,1');
            Route::get('/export/student/{studentId}/csv', [ReportController::class, 'exportStudentReportCSV'])
                ->middleware('throttle:5,1');
            Route::get('/export/grades/csv', [ReportController::class, 'exportGradesCSV'])
                ->middleware('throttle:5,1');
        });
        
        // ============================================================
        // PADRES DE FAMILIA (Solo Parent)
        // ============================================================

        Route::prefix('parent')->middleware('role:parent')->group(function () {
            Route::get('/children', [ParentController::class, 'index']);
            Route::get('/children/{studentId}/progress', [ParentController::class, 'childProgress']);
            Route::get('/children/{studentId}/report', [ParentController::class, 'childReport']);
        });

        // ============================================================
        // ADMINISTRACIÓN (Solo Admin)
        // ============================================================
        
        Route::prefix('admin')->middleware(['role:admin'])->group(function () {
            
            Route::prefix('users')->group(function () {
                Route::get('/', [AdminController::class, 'getUsers'])
                    ->middleware('cache.api');
                Route::post('/', [AdminController::class, 'createUser']);
                Route::post('/import', [AdminController::class, 'importUsers'])
                    ->middleware(['throttle:5,1']);
                Route::get('/export', [AdminController::class, 'exportUsers']);
                Route::get('/{id}', [AdminController::class, 'getUser'])
                    ->middleware('cache.api');
                Route::put('/{id}', [AdminController::class, 'updateUser']);
                Route::delete('/{id}', [AdminController::class, 'deleteUser']);
                Route::post('/{id}/activate', [AdminController::class, 'activateUser']);
                Route::post('/{id}/deactivate', [AdminController::class, 'deactivateUser']);
            });
            
            Route::prefix('config')->group(function () {
                Route::get('/', [AdminController::class, 'getConfig'])
                    ->middleware('cache.api');
                Route::put('/', [AdminController::class, 'updateConfig']);
            });
            
            Route::prefix('periods')->group(function () {
                Route::get('/', [AdminController::class, 'getPeriods'])
                    ->middleware('cache.api');
                Route::post('/', [AdminController::class, 'createPeriod']);
                Route::put('/{id}', [AdminController::class, 'updatePeriod']);
                Route::delete('/{id}', [AdminController::class, 'deletePeriod']);
            });
            
            Route::prefix('backup')->group(function () {
                Route::post('/', [AdminController::class, 'createBackup'])
                    ->middleware(['throttle:3,60']);
                Route::get('/last', [AdminController::class, 'getLastBackup'])
                    ->middleware('cache.api');
                Route::get('/download/{filename}', [AdminController::class, 'downloadBackup']);
            });

            Route::prefix('translations')->group(function () {
                Route::get('/', [SystemTranslationController::class, 'index'])
                    ->middleware('cache.api');
                Route::post('/', [SystemTranslationController::class, 'store'])
                    ->middleware(['throttle:60,1']);
                Route::post('/bulk', [SystemTranslationController::class, 'bulkUpdate'])
                    ->middleware(['throttle:30,1']);
                Route::delete('/{id}', [SystemTranslationController::class, 'destroy']);
            });

            Route::post('/achievements/sync', [GamificationController::class, 'sync']);
        });

    // ============================================================
    // GAMIFICACIÓN (Estudiante autenticado)
    // ============================================================

    Route::prefix('gamification')->middleware(['role:student'])->group(function () {
        Route::get('/summary', [GamificationController::class, 'summary'])
            ->middleware('cache.api');
        Route::post('/check', [GamificationController::class, 'check'])
            ->middleware('throttle:20,1');
    });

    // ============================================================
    // CALENDARIO ACADÉMICO (Docente/Admin)
    // ============================================================

    Route::prefix('calendar')->middleware(['role:teacher,admin'])->group(function () {
        Route::get('/', [AcademicEventController::class, 'index'])
            ->middleware('cache.api');
        Route::post('/', [AcademicEventController::class, 'store']);
        Route::put('/{id}', [AcademicEventController::class, 'update']);
        Route::delete('/{id}', [AcademicEventController::class, 'destroy']);
    });

    // ============================================================
    // PUSH NOTIFICATIONS WEB (Autenticado)
    // ============================================================

    Route::prefix('push')->group(function () {
        Route::get('/config', [PushSubscriptionController::class, 'config'])
            ->middleware('cache.api');
        Route::post('/subscribe', [PushSubscriptionController::class, 'store'])
            ->middleware(['throttle:10,1']);
        Route::post('/unsubscribe', [PushSubscriptionController::class, 'destroy']);
        Route::post('/test', [PushSubscriptionController::class, 'test'])
            ->middleware('throttle:5,1');
    });

    // ============================================================
    // MENSAJERÍA DOCENTE-ESTUDIANTE (Autenticado, anti-IDOR)
    // ============================================================

    Route::prefix('conversations')->middleware(['throttle:30,1'])->group(function () {
        Route::get('/', [MessageController::class, 'index']);
        Route::post('/', [MessageController::class, 'store']);
        Route::get('/{id}', [MessageController::class, 'show']);
        Route::post('/{id}/reply', [MessageController::class, 'reply']);
    });

    // ============================================================
    // FORO DE CLASE (Docentes crean hilos, estudiantes comentan)
    // ============================================================

    Route::prefix('forum')->middleware(['throttle:30,1'])->group(function () {
        Route::get('/', [ForumController::class, 'index']);
        Route::post('/', [ForumController::class, 'store']);
        Route::get('/{id}', [ForumController::class, 'show']);
        Route::post('/{id}/post', [ForumController::class, 'post']);
        Route::post('/{id}/close', [ForumController::class, 'close']);
    });

    // ============================================================
    // SALONES, CURSOS Y LECCIONES POR SALÓN (Coordinador/Docente/Estudiante)
    // ============================================================

    Route::prefix('salones')->middleware(['throttle:60,1'])->group(function () {
        Route::get('/', [SalonController::class, 'index']);
        Route::post('/', [SalonController::class, 'store']);
        Route::get('/{id}', [SalonController::class, 'show']);
        Route::put('/{id}', [SalonController::class, 'update']);
        Route::delete('/{id}', [SalonController::class, 'destroy']);

        // Cursos del salón
        Route::get('/{salonId}/courses', [SalonController::class, 'courses']);
        Route::post('/{salonId}/courses', [SalonController::class, 'storeCourse']);

        // Alumnos del salón
        Route::get('/{salonId}/students', [SalonController::class, 'salonStudents']);
        Route::post('/{salonId}/students', [SalonController::class, 'storeStudent']);
        Route::post('/{salonId}/students/import', [SalonController::class, 'importStudents']);
    });

    // Catálogos para coordinador/director
    Route::get('/catalog/teachers', [SalonController::class, 'teachers']);
    Route::get('/catalog/students', [SalonController::class, 'students']);

    // Cursos (lecciones, matrícula)
    Route::prefix('courses')->middleware(['throttle:60,1'])->group(function () {
        Route::put('/{courseId}', [SalonController::class, 'updateCourse']);
        Route::delete('/{courseId}', [SalonController::class, 'destroyCourse']);

        Route::get('/{courseId}/lessons', [SalonController::class, 'courseLessons']);
        Route::post('/{courseId}/lessons', [SalonController::class, 'storeLesson']);

        Route::post('/{courseId}/enroll', [SalonController::class, 'enroll']);
        Route::post('/{courseId}/unenroll', [SalonController::class, 'unenroll']);
        Route::get('/{courseId}/students', [SalonController::class, 'courseStudents']);
        Route::get('/{courseId}', [SalonController::class, 'studentCourseDetail']);

        // Auto-matrícula del estudiante por código de curso
        Route::post('/enroll-by-code', [SalonController::class, 'enrollByCode']);
    });

    // JUEGOS DIDÁCTICOS (Quizizz/Kahoot) + comprobante de puntaje
    Route::prefix('games')->middleware(['throttle:60,1'])->group(function () {
        Route::get('/', [GameController::class, 'index']);
        Route::post('/', [GameController::class, 'store']);
        Route::get('/teacher-courses', [GameController::class, 'teacherCourses']);
        Route::get('/{gameId}', [GameController::class, 'show']);
        Route::put('/{gameId}', [GameController::class, 'update']);
        Route::delete('/{gameId}', [GameController::class, 'destroy']);
        Route::post('/{gameId}/screenshot', [GameController::class, 'uploadScreenshot']);
        Route::post('/{gameId}/submit', [GameController::class, 'submit']);
        Route::post('/submissions/{submissionId}/grade', [GameController::class, 'grade']);
    });
    });

    // ============================================================

    Route::post('/guest/student-lookup', [GuestStudentController::class, 'lookup'])->middleware('throttle:5,1');
    Route::get('/guest/captcha', [GuestStudentController::class, 'generateCaptcha'])->middleware('throttle:10,1');

    // ============================================================
    // RUTAS PÚBLICAS (Sin autenticación)
    // ============================================================

    Route::get('/config', [AdminController::class, 'publicConfig'])
        ->middleware('throttle:30,1');

    Route::get('/translations/overrides', [SystemTranslationController::class, 'publicOverrides'])
        ->middleware('throttle:60,1');

    // ============================================================
    // HEALTH CHECK
    // ============================================================

    Route::get('/health', function () {
        return response()->json([
            'status' => 'healthy',
            'message' => 'Mentemática API is running',
            'version' => 'v1',
            'timestamp' => now()
        ]);
    });
});
